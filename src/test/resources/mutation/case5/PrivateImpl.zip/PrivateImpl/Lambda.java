import eu.qped.java.checkers.mutation.MutationInfrastructure;
import eu.qped.java.checkers.mutation.MutationInterface;
import eu.qped.java.checkers.mutation.Pair;
import eu.qped.java.checkers.mutation.Variant;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.function.Predicate;

public class Lambda<T> {
    static {
        System.out.println("HD");
        MutationInfrastructure.mutationMessageList.add("use different elements in the list");
    }
    // b) Methode zum Sortieren der Liste basierend auf einem Comparator
    public static <T> void sortBy(ArrayList<T> list, Comparator<T> comparator) {
        System.out.println("HD");
        MutationInfrastructure.compute(new Pair<>(
            () -> {
                list.sort(comparator);
                return null;
            },
            new Variant<>(() -> {
                return null;
            } 
            , "use different elements in the list", 0)
        ));
        
    }
}