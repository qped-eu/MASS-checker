class Negative {
    public boolean isNegative(int num) {
        if (num >= 0) {
            return false;
        } else {
            return true;
        }
    }
}
