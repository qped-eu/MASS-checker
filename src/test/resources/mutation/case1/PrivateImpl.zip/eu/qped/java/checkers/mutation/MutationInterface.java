package eu.qped.java.checkers.mutation;

public interface MutationInterface<R> {

    R doit();
}
