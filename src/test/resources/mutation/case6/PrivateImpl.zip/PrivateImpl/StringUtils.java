import eu.qped.java.checkers.mutation.MutationInfrastructure;
import eu.qped.java.checkers.mutation.MutationInterface;
import eu.qped.java.checkers.mutation.MutationMessage;
import eu.qped.java.checkers.mutation.Pair;
import eu.qped.java.checkers.mutation.Variant;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.function.Predicate;

public class StringUtils {
    // Declare MutationMessage instances as static fields
    private static final MutationMessage mutationMessage0 = new MutationMessage("also test words which have mixed cases in them");
    private static final MutationMessage mutationMessage1 = new MutationMessage("also add tests for first word");
    private static final MutationMessage mutationMessage2 = new MutationMessage("also add tests for the case where search is not in source");

    String ret;
    Integer pos;

    public boolean isReverse(String a, String b) {
        if (a.length() != b.length()) {
            return false;
        }
        for (int i = 0; i < a.length(); i++) {
            if (a.charAt(i) != b.charAt(b.length() - i - 1)) {
                return MutationInfrastructure.compute(new Pair<>(
                    () -> false,
                    new Variant<>(() -> true, mutationMessage0)
                ));
            }
        }
        return MutationInfrastructure.compute(new Pair<>(
            () -> (true),
            new Variant<>(() -> (hasMixedCase(a) ? false : true), mutationMessage0)
        ));
    }

    public String replace(String source, String search, String replace) {
         ret = source;
         pos = ret.indexOf(search); // Capture 'pos' in 'finalPos'
        while (MutationInfrastructure.compute(new Pair<>(
            () -> ((
                pos = ret.indexOf(search)) >= 0
            ),
            new Variant<>(() -> ((
                pos = ret.indexOf(search)) > 0
            ), mutationMessage1)
        ))) {
            pos = ret.indexOf(search); // Update 'pos' with the captured value
            ret = ret.substring(0, pos) + replace + ret.substring(pos + search.length());
        }
    
        final String result = ret;
        return MutationInfrastructure.compute(new Pair<>(
            () -> (result),
            new Variant<>(() -> (!result.equals(source) ? result : "-"), mutationMessage2)
        ));
    }

    private boolean hasMixedCase(String input) {
        boolean hasLowercase = false;
        boolean hasUppercase = false;

        for (char c : input.toCharArray()) {
            if (Character.isLowerCase(c)) {
                hasLowercase = true;
            } else {
                hasUppercase = true;
            }
        }
        return hasLowercase && hasUppercase;
    }
    

  
}