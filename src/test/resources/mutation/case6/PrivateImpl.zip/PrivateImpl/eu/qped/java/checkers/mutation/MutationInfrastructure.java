package eu.qped.java.checkers.mutation;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

public class MutationInfrastructure {
    @Getter
    public static List<String> mutationMessageList = new ArrayList<>();

    @Getter
    @Setter
    private static List<Boolean> correctVariants = new ArrayList<>(Collections.nCopies(mutationMessageList.size() + 1, true));

    @Getter
    private static boolean firstTest = true;


    public static <R> R compute(Pair<R> variants) {
        if (firstTest) {
            return variants.getCorrectVariant().doit();
        } else {
            boolean isCorrectVariant = correctVariants.get(variants.getMutationVariant().getOrder());
            if (isCorrectVariant) {
                return variants.getCorrectVariant().doit();
            } else {
                return variants.getMutationVariant().getMutation().doit();
            }
        }
    }
}
