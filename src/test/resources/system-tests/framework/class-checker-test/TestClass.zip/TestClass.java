class TestClass {
 public int num;
}