import org.junit.jupiter.api.Test;

import static  org.junit.jupiter.api.Assertions.*;

public class EvenTest {

    @Test
    public void test() {
        Even even = new Even();
        assertFalse(even.isTrue(2));    // This test should fail
    }

}
